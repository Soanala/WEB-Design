<!DOCTYPE html>
<html>
<head>
	<title>Acceuil</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="acceuil.css">
	<form action="redirection.php" method="post">
</head>
<body>
	<center><div class="src"><p><input type="text" name="genre">
	<input type="submit" value="Rechercher"></p></div></center>
	<h1><a href="recherche.php">Plus de filtre</a></h1>
	<h2>Ce zoo est une organisation internationale de conservation à but non lucratif avec deux portes d'entrée. Nous intégrons la santé et les soins de la faune, la science et l'éducation pour développer des solutions de conservation durables. La conservation est au cœur de tout ce que nous faisons. Et cela commence par ce lien que nous établissons quotidiennement avec les gens et la faune. Parce que lorsque la faune prospère, toute vie prospère.</h2>
	<div class="entete"><center><p><strong><span>Conservation dans le monde</span></strong><br>Cette carte met en évidence les domaines dans lesquels nous concentrons notre travail de conservation pour soutenir la faune, les communautés et les écosystèmes du monde entier.</p></center></div>
	<table>
		<tr>
			<th><div>
				<div class="corp"><span id="titre"><strong>Nouvelles et ressources</strong></span><br><span id="texte">Trouvez des informations détaillées sur les 	animaux</span></div>
			</th>
			<th>
				<a href="../animal/animal.php"><div id="partie1"><p>Animal</p></div></a></th>
		<tr>
			<th><a href="../sauvons/save.php"><div id="partie3"><p>Sauvons les animaux</p></div></a></th>
			<th><center><div>
		<h1 class="follow">SUIVEZ NOUS</h1>
		<table>
			<tr>
				<th><img src="fbicon.png" width="60px"></th>
				<th><img src="instaicon.png" width="60px"></th>
				<th><img src="twitter.png" width="60px"></th>
				<th><img src="tikicon.png" width="60px"></th>
				<th><img src="whaticon.png" width="60px"></th>
				<th><img src="youtubeicon.png" width="60px"></th>
			</tr>
		</table>
	</div></center></th>
		</tr>
	</table>
	<center>
	<div class="foot">
	<p>Auteur et createur :</p>
	<p><h2>ETU001466_RAMANAMPAMONJY RIANTSOA LAHATRINIAINA</h2></p>
	<p><h2>ETU001427_RAHARIVAO Soanala Mariah</h2></p>
	
	</div>
	</center>
</body>
</html>