<?php
$genre[0]['amphibien']='Amphibien';
$genre[0]['reptile']='Reptile';
$genre[0]['poisson']='Poisson';
$genre[0]['insecte']='Insecte';
$genre[0]['mamifere']='Mamifere';
?>	