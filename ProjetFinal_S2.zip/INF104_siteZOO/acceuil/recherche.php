<!DOCTYPE html>
<html>
<head>
	<title>Recherche</title>
	<meta charset="utf-8">
<form action="redirection3.php" method="post">
	<link rel="stylesheet" type="text/css" href="recherche.css">
	<center>
		<p>Nous attendons avec impatience votre suggestion</p></center>
</head>
<body>
 <center><p><h1>Appartenance de la famille de l'animal</h1>
            <select name="genre" >
                <option value="">Tous</option>
                <option value="10">Amphibien</option>
                <option value="20">Poisson</option>
                <option value="30">Insecte</option>
                <option value="40">Reptile</option>
				 <option value="50">Mamifere</option>
            </select>
            </p>
            </p>
            <p><h1>CONTINENT</h1>
            <select name="pays">
                <option value="">Tous</option>
                <option value="30">Amerique</option>
                <option value="20">Europe</option>
                <option value="10">Afrique</option>
                <option value="40"></option>
            </select>
            </p>
            <p><input type="submit" value="rechercher"></p>
            </center>
</body>
</html>