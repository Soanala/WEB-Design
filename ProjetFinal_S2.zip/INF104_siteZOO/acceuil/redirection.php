<?php
include ("dataa.php");
session_start();
$nom=$_POST['genre'];

if ($nom==$genre[0]['amphibien']) 
{
	header('Location:../animal/amphibien/amphibien.php');
}
else if ($nom==$genre[0]['reptile']) 
{
	header('Location:../animal/oiseaux/reptile.php');
}
else if ($nom==$genre[0]['poisson']) 
{
	header('Location:../animal/oiseaux/aqua.php');
}
else if ($nom==$genre[0]['insecte']) 
{
	header('Location:../animal/oiseaux/insec.php');
}
else if ($nom==$genre[0]['mamifere']) 
{
	header('Location:../animal/oiseaux/mam.php');
}
else 
{
	header('Location:acceuil.php');
}

?>