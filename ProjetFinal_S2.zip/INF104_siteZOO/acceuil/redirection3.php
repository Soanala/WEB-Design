<?php
include('recherche.php');
session_start();
$ok=$_POST['genre'];
$oo=$_POST['pays'];
if ($ok=='10') 
{
  header('Location:../animal/amphibien/amphibien.php');
}
 else if ($ok=='20') 
{
  header('Location:../animal/oiseaux/aqua.php');
} 
else if ($ok=='30') 
{
  header('Location:../animal/oiseaux/insec.php');
} 
else if ($ok=='40') 
{
  header('Location:../animal/oiseaux/reptile.php');
}
else if ($ok=='50') 
{
  header('Location:../animal/oiseaux/mam.php');
}

if ($oo=='10') 
{
  header('Location:../animal/amphibien/amphibien.php');
}
 else if ($oo=='20') 
{
  header('Location:../animal/oiseaux/aqua.php');
} 
else if ($oo=='30') 
{
  header('Location:../animal/oiseaux/insec.php');
} 
else if ($oo=='40') 
{
  header('Location:../animal/oiseaux/reptile.php');
}  
?>