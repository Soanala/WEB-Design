<!DOCTYPE html>
<html>
<head>
	<title>Amphibien</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="amphibien.css">
</head>
<body>
		<div class="poison">
			<h2>Grenouille Venimeuse</h2>
			<p>La grenouille venimeuse est considérée comme l'animal le plus venimeux du monde, produisant à la fois suffisamment de toxine nerveuse pour tuer 10 humains.</p>
		</div>
		<hr>>
		<div class="Mantella">
			<h2>Mantella</h2>
			<p>Les scientifiques pensaient autrefois que les mantelles de Madagascar et les grenouilles venimeuses d'Amérique du Sud étaient étroitement liées. Mais des études ADN ont montré qu'il ne s'agissait que de parents éloignés avec des couleurs vives et d'avertissement similaires.</p>
		</div>
		<hr>
		<div class="retine">
			<h2>Rainette aux yeux rouges</h2>
			<p>La rainette aux yeux rouges, souvent appelée par erreur en français « grenouille aux yeux rouges »</p>
		</div>
		<hr>
		<div class="crapaud">
			<h2>Crapaud Calamite</h2>
			<p>Le Crapaud calamite ou Crapaud des joncs, Epidalea calamita, unique représentant du genre Epidalea, est une espèce d'amphibiens de la famille des Bufonidae.</p>
		</div>
</body>
</html>