<!DOCTYPE html>
<html>
<head>
	<title>Animal</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="animal.css">
</head>
<body>
	<div class="titre">
	<h1>Nos animaux</h1>
	</div>
	<div>
		<table>
			<tr>
				<th>
					<a href="amphibien/amphibien.php"><div class="Amphibiens">
					</div></a>
				</th>
				<th><a href="oiseaux/insec.php">
					<div class="insect">
					</div></a>
				</th>
				<th><a href="oiseaux/oiseaux.php">
					<div class="oiseau">	
					</div></a>
				</th>
			</tr>
			<tr>
				<th><a href="oiseaux/aqua.php">
					<div class="poisson">
						
					</div></a>
				</th>
				<th><a href="oiseaux/mam.php">
					<div class="mamifere">
						
					</div></a>
				</th>
				<th><a href="oiseaux/reptile.php">
					<div class="reptile">
						
					</div></a>
				</th>
			</tr>
		</table>
	</div>
</body>
</html>