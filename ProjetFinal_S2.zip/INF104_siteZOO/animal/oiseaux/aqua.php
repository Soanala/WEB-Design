<!DOCTYPE html>
<html>
<head>
	<title>AQUA</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="aqua.css">
</head>
<body>
		<div class="med">
			<h2>MÉDUSE COMMUNE</h2>
			<p>Sans squelette, sans carapace et sans coquille de protection, la méduse est faite d’une matière gélatineuse translucide blanc-bleuté composé à 98% d’eau. Son corps à la forme d’une ombrelle.es populations seraient en augmentation constante et l’espèce n’est pas menacée d’extinction.</p>
		</div>
		<hr>>
		<div class="tor">
			<h2>
               TORTUE CHARBONNIÈRE</h2>
			<p>La tortue charbonnière aurait servie de nourriture aux indiens précolombiens lors de voyages, ce qui explique leur introduction dans les îles d’Amérique du Sud.les tortues sont de nature silencieuse. Chez la tortue charbonnière, le mâle émet un gloussement particulier qui est spécifique à cette espèce.
              Bien qu’elle soit considérée comme abondante en nature, son commerce n’est pas contrôlé et donc sujet à faire chuter les populations sauvages.
</p>
		</div>
		<hr>
		<div class="ra">
			<h2>
                 RAIE CHAUVE-SOURIS</h2>
			<p>Elle possède un repli au milieu du museau qui le divise en deux gros lobes, à la manière du museau des vaches, d’où son nom anglais « Cownose ray ».Elles peuvent sauter hors de l’eau, probablement pour fuir un prédateur. Elles se déplacent en « battant » des nageoires, à l’image d’un oiseau.</p>
		</div>
		<hr>
		<div class="req">
			<h2>REQUIN À POINTES NOIRES</h2>
			<p>
                   Il est merveilleusement bien adapté pour la chasse et pour évoluer dans le milieu marin : son corps en fuseau est hydrodynamique et lui permet d’atteindre des vitesses de 37 km/h. Ses dents se renouvellent constamment, les conservant ainsi tranchantes comme un couteau </p>
		</div>
</body>
</html>