<!DOCTYPE html>
<html>
<head>
	<title>AQUA</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="insec.css">
</head>
<body>
	<center><img src="" width="300px"></center>
		<div class="pap">
			<h2>PAPILLON</h2>
			<p>Le papillon est la phase final de l'eclosion du crysalite de la chenille.Il est l'insecte le plus fascinant,majestueux et aide l'homme dans la fecondation des fleurs tel que les gousses de vanilles.La legende urbaine raconte l'eclosion d'un papillon comme un evenement qui vas etre catastrophique:c'est l'effet papillon.</p>
		</div>
		<hr>
		<div class="gu">
			<h2>GUEPE</h2>
			<p>la guepe est de la meme famille que l'abeille.Sa piquere est douleureuse et venimeuse mais non mortel.La guepe aide parfois son cousin pour assurer la descendance ainsi que la garde de la ruche.Une piqure de guepe est mortel pour certain animaux mais pour l'homme plusieurs piqures consecutives le tue.
            </p>
		</div>
		<hr>
		<div class="sca">
			<h2>ABEILLE
                 </h2>
			<p>C'est l'insecte qui aide le plus l'Homme grace a son miel delicieux,et medicinale mais aussi grace a la polinisation florale qu'elle fait.Elles arrivent a donne 500.000 litres de miel par jour dot 15 milliard de litres de miels tous les ans.A part le chien,L'abeille est le meilleur allie de l'Homme</p>
		</div>
	
</body>
</html>