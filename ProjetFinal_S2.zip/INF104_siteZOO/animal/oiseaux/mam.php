<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="mam.css">
</head>
<body>
		<div class="petit">
			<h2>PETIT PANDA</h2>
			<p>Cet animal dort et se repose souvent perché dans un arbre. Il choisira de préférence un endroit orienté vers le sud, pour profiter de la chaleur du soleil.Le petit panda est l’emblème de la province indienne de Sikkim et la mascotte du Festival International de Thé de Darjeeling, en Inde également.
       </p>
		</div>
		<hr>
		<div class="al">
			<h2>ALPAGA</h2>
			<p>L’alpaga vit à des altitudes variant entre 1 000 et 4 800 mètres. Le taux élevé de globules sanguins dans son sang permet de compenser les niveaux d’oxygène plus faibles rencontrés à ces hauteurs.
Il possède une laine épaisse et solante qui lui permet de conserver sa chaleur et de braver les températures  rigoureuses </p>
		</div>
		<hr>
		<div class="lama">
			<h2>LAMA</h2>
			<p>l possède une laine épaisse et isolante qui permet de le garder au chaud. En se roulant sur le sol, il desserre les fibres de sa laine et s’assure ainsi de conserver les propriétés isolantes de son pelage.
             Agacé, le lama couche les oreilles et montre des dents.</p>
		</div>
		<hr>
		<div class="go">
			<h2>GORILLE DES PLAINES</h2>
			<p>C’est le plus gros des primates! Le mâle peut atteindre 275 kg (600 lb)! La femelle est habituellement presque deux fois plus petite.
              Sa musculature est imposante.il est capable de repérer l’odeur d’un humain à une distance de 20 m… en forêt tropicale!</p>
		</div>
</body>
</html>