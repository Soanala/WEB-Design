<!DOCTYPE html>
<html>
<head>
	<title>Oiseaux</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="oiseaux.css">
</head>
<body>
		<div class="ara">
			<h2>ARA BLEU</h2>
			<p>C’est un oiseau qui communique…bruyamment! Une espèce qui est toujours vulnérable à la capture pour le commerce des animaux de compagnie.
			Les aras bleus vivent en groupes familiaux de 30 à 50 individus. Les couples se forment habituellement pour la vie.</p>
		</div>
		<hr>>
		<div class="condor">
			
            <h2> CONDOR DES ANDES</h2>
			<p>Cet oiseau possède une vue perçante qui lui permet de repérer ses proies à plusieurs kilomètres de distance.
			il fait partie intégrante des traditions sud-américaines : il représente un symbole de libération de l’âme lors des rituels de sépulture. le condor peut se maintenir dans les airs pendant des heures .</p>
		</div>
		<hr>
		<div class="loriquet">
			<h2>LORIQUET ARC-EN-CIEL</h2>
			<p>
               Les loriquets sont pourvus d’une langue particulière, longue, étroite et poilue qui leur sert à récolter le pollen et le nectar des fleurs.Ce sont de véritables acrobates! Les loriquets sont grégaires et nomades et d’important pollinisateurs dans leur milieu naturel</p>
		</div>
		<hr>
		<div class="flamant">
			<h2>FLAMANT DES CARAÏBES</h2>
			<p>
                Sa belle couleur rose provient des pigments de carotène contenus dans son alimentation à base de petits crustacés.Il s’alimente par filtration.Très résistant à son environnement, il peut supporter des températures extérieures de 68°C, patauger dans une eau alcaline (pH 11).Ils sont menacés par le développement et les perturbations humaines.</p>
		</div>
</body>
</html>