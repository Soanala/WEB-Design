<!DOCTYPE html>
<html>
<head>
	<title>Oiseaux</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="reptile.css">
</head>
<body>
		<div class="boa">
			<h2>BOA CONSTRICTEUR</h2>
			<p>Ce chasseur à l’affût peut mesurer jusqu’à quatre mètres et peser jusqu’à 18 kg.C’est un excellent nageur, utilisant les ondulations de son corps pour se propulser. Grâce à sa capacité à demeurer immobile longtemps, il excelle à la chasse par embuscade.L’espèce ne jouit pas d’un statut particulier; par contre, sa grande popularité comme animal de compagnie le rend vulnérable au commerce illicite</p>
		</div>
		<hr>
		<div class="cam">
			<h2>
                  CAMÉLÉON PANTHÈRE</h2>
			<p>Ce reptile possède une langue aussi longue que son corps (jusqu’à 55 cm).Elle se termine par une extrémité musclée et collante. Elle se déploie à une vitesse moyenne de 21km/h!Il peut changer de couleur en quelques secondes. Sa couleur varie selon le stress, la peur, la luminosité,</p>
		</div>
		<hr>
		<div class="python">
			<h2>PYTHON ROYAL</h2>
			<p>
                Une caractéristique propre à ce serpent est sa méthode de défense; loin d’être agressif,Deux petits crochets sont visibles de chaque côté du cloaque.Le python royal est un serpent populaire en tant qu’animal de compagnie. C’est aussi le serpent le plus abondant dans les parcs zoologiques et dans les collections privées.
                                                                                                   </p>
		</div>
		<hr>
		<div class="uro">
			<h2>
                  UROMASTIX DU MALI</h2>
			<p>Sa large queue sert de réserve de graisse… et de massue!Ses principaux prédateurs sont le chat des sables, le renard de Rüppell et certains oiseaux de proie.Ce lézard est très populaire comme animal de compagnie. Ce commerce est l’une des principales menaces qui pèsent sur lui. Il est également utilisé en médecine traditionnelle par certains bédouins du désert.

</p>
		</div>
</body>
</html>