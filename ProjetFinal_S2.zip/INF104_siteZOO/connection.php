<?php
	session_start();
	$_SESSION['nom1']='Lahatra';
	$_SESSION['nom2']='Soanala';
	
	$_SESSION['mdp1']='0000';
	$_SESSION['mdp2']='1111';
	
	$_SESSION['name']=$_POST['nom'];
	$mdp=$_POST['mdp'];
	if($_SESSION['name']==$_SESSION['nom1'])
	{
		if($mdp==$_SESSION['mdp1'])
		{
			header("location:acceuil/acceuil.php");
		}
		else
		{
			$phrase="Votre Mot de passe est incorrect";
		}
	}
	elseif($_SESSION['name']==$_SESSION['nom2'])
	{
		if($mdp==$_SESSION['mdp2'])
		{
			header("location:acceuil/acceuil.php");
		}
		else
		{
			$phrase="Votre Mot de passe est incorrect";
		}
	}
	elseif($_SESSION['name']==$_SESSION['nom3'])
	{
		if($mdp==$_SESSION['mdp3'])
		{
			header("location:acceuil/acceuil.php");
		}
		else
		{
			$phrase="Votre Mot de passe est incorrect";
		}
	}
	else
	{
		header("location:noname.php");
	}
?>	
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
	<section>
		<div class="login">
		<div class="form">
			<h2>Login</h2>
			<form action="connection.php" method="post">
			<div class="input">
				<input type="text" placeholder="Nom d'utilisateur" name="nom">
				<img src="user.png" width="20">
			</div>
			<div class="input">
				<input type="password" placeholder="Mot de passe" name="mdp">
				<img src="lock.png" width="20">
			</div>
			<div class="input">
				<input type="submit" value="Se connecter">
				<p style="color: rgb(255,255,255);"><?php echo $phrase;?></p>
			</div>
		</div>
		</div>
	</section>
</body>
</html>