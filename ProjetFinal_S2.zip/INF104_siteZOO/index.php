<!DOCTYPE html>
<html>
<head>
	<title>Index.php</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
	<center><div class="text">
		<h2>Bienvenue</h2>
		<h2>Bienvenue</h2>
	</div></center>
	<div>
		<a href="login.php">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
			COMMENCER LA VISITE
		</a>
	</div>
</body>
</html>