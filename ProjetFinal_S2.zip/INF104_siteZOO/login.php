<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
	<section>
		<div class="login">
		<div class="form">
			<h2>Login</h2>
			<form action="connection.php" method="post">
			<div class="input">
				<input type="text" placeholder="Nom d'utilisateur" name="nom">
				<img src="user.png" width="20">
			</div>
			<div class="input">
				<input type="password" placeholder="Mot de passe" name="mdp">
				<img src="lock.png" width="20">
			</div>
			<div class="input">
				<input type="submit" value="Se connecter">
			</div>
		</div>
		</div>
	</section>
</body>
</html>