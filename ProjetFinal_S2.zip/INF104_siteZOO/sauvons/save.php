<!DOCTYPE html>
<html>
<head>
	<title>Sauvons les animaux</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="save.css">
	<center><h1>Sauver les animaux, pour nous sauver nous-mêmes</h1></center>
</head>
<body>
<center><img src="sary/page.jpg" width="500px"></center>
<h2>D'ici une vingtaine d'années, nous mangerons davantage de viande de synthèse que de chair animale. Une perspective dont il faut se réjouir, selon Gaspard Koenig, car elle permet à la fois d'éviter les souffrances des animaux d'élevage et de lutter contre le réchauffement climatique.</h2>
<h4>Dans un récent rapport pour « repenser l'alimentation et l'agriculture », le cabinet AT Kearney estime que, d'ici 2040, la majorité de la viande que nous mangerons ne proviendra pas de chair animale, mais sera cultivée en laboratoire ou composée de végétaux. Puisque son appellation est encore disputée, baptisons-la « viande de synthèse ». Ses techniques de fabrication sont en amélioration constante , tandis que son coût de production devrait passer sous celui de la viande traditionnelle. C'est une excellente nouvelle, que le moine bouddhiste Matthieu Ricard a partagée avec enthousiasme dans son blog hebdomadaire. La viande de synthèse ouvre en effet la voie à un monde affranchi de la souffrance animale, réconciliant technologie, innovation et respect des êtres sensibles.</h4>
<h4>Notre association a pour but d’aider et sauver des animaux en détresse ainsi que des animaux sur les listes des refuges , qui attendent pour être malheureusement euthanasiés. Notre équipe ne possède pas de structure pour accueillir les chiens et les chats., nous fonctionnons uniquement grâce à des familles d’accueil (FA). Nous sommes à la recherche de FA . Être FA c’est aussi faire une bonne action en aidant la cause animale, et cela permet à l’animal de trouver la chaleur d’un foyer. Être Famille d’accueil peut aussi vous permettre de vérifier si votre vie serait compatible avec celle d’un animal avant de vous décider à adopter. Si vous voulez devenir FA pour chiens, chats, envoyez nous un mail à : amouranimal@gmail.com Indiquez vos coordonnées complètes ainsi que vos disponibilités à court ou moyen terme.Nous vous recontacterons très rapidement. C’est grâce à votre générosité que nous pourrons leur offrir la vie idéale à laquelle ils ont droit !</h4>
<h2>Les actions de notre association
</h2>
<h3>Sauvetages de chiens menacés d'euthanasie</h3>
<h4>Chaque jour des centaines de chiens, de tous âges et de toutes tailles sont euthanasiés dans les fourrières et ce dans la plus grande indifférence. Rêv'Animal essaie dans la mesure du possible de faire sortir ces animaux de fourrière. Malheureusement, nous sommes limités dans la capacité d'accueil, car nous ne fonctionnons qu'avec des familles d'accueil. Nous avons donc besoin de familles d'accueils sur Paris et sa région pour pouvoir sauver plus d'animaux.</h4>
</body>
</html>